//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NewTetris.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_NEWTETTYPE                  129
#define IDD_DIALOG1                     130
#define IDB_BITMAP1                     131
#define IDB_BITMAP2                     133
#define IDB_BITMAP3                     135
#define IDC_HAND                        136
#define IDR_WAVA1                       137
#define IDR_WAVE1                       138
#define IDR_WAVE2                       139
#define IDR_WAVE3                       140
#define IDI_ICON1                       141
#define IDC_LINK                        1000
#define ID_Game_Start                   32771
#define ID_DIFF_EASY                    32772
#define ID_DIFF_MID                     32773
#define ID_DIFF_SUP                     32774
#define IDD_HELP1                       32775
#define IDD_Pause                       32777
#define IDD_Restart                     32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
