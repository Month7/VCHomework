//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by studentba.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_STUDENTBA_FORM              101
#define IDP_FAILED_OPEN_DATABASE        103
#define IDR_MAINFRAME                   128
#define IDR_STUDENTYPE                  129
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_EDIT4                       1003
#define IDC_EDIT5                       1004
#define IDC_EDIT6                       1005
#define IDC_EDIT7                       1006
#define IDC_BUTTON1                     1007
#define IDC_BUTTON2                     1008
#define IDC_BUTTON3                     1009
#define IDC_BUTTON4                     1010
#define IDC_BUTTON5                     1011
#define IDC_BUTTON6                     1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
