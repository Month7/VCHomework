//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Student.rc
//
#define IDC_STUADDR                     1
#define IDOK2                           2
#define IDCANCEL2                       3
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_STUDENTYPE                  129
#define IDB_BITMAP_BG                   133
#define IDD_DIALOG_LOGIN                134
#define IDD_DIALOG_USER                 135
#define IDD_DIALOG_STUDENT              136
#define IDD_DIALOG_STUDENT_INFO         137
#define IDD_DIALOG_SCORE_INPUT          139
#define IDD_DIALOG_SCORE                140
#define IDD_DIALOG_SEARCH               141
#define IDD_DIALOG_WRITER               142
#define IDD_DIALOG_SCORE_UP             143
#define IDD_DIALOG1                     144
#define IDC_USER                        1000
#define IDC_PASSWD                      1001
#define IDC_BUTTON1                     1002
#define IDC_BnClickedOk                 1002
#define IDC_BUTTON_NEW                  1002
#define IDC_BUTTON_INPUT                1002
#define IDC_BUTTON2                     1003
#define IDC_USERNAME                    1003
#define IDC_BUTTON1_MODIFY              1003
#define IDC_PASSWORD1                   1004
#define IDC_BUTTON_DELETE1              1004
#define IDC_BUTTON1_DELETE              1004
#define IDC_PASSWORD2                   1005
#define IDC_BUTTON_BROWSE               1005
#define IDC_BnClickedButtonSearch       1005
#define IDC_BUTTON_DELETE               1006
#define IDC_BUTTON_SEARCH               1008
#define IDC_LIST_USERNAME               1010
#define IDC_CHECK1                      1011
#define IDC_BUTTON_MODIFY               1012
#define IDC_DEPARTMENT                  1013
#define IDC_MAJOR                       1014
#define IDC_CLASS                       1015
#define IDC_LIST1                       1016
#define IDC_STUCODE                     1017
#define IDC_STUSEX                      1018
#define IDC_STUDEPARTMENT               1019
#define IDC_STUCLASS                    1020
#define IDC_STUBIRTH                    1021
#define IDC_STUNAME                     1022
#define IDC_CLASS1                      1022
#define IDC_EXAMCLASS                   1023
#define IDC_EDIT_SCORE                  1023
#define IDC_STUMAJOR                    1024
#define IDC_TIME                        1024
#define IDC_EDIT_MAKEUP                 1024
#define IDC_STUPHONE                    1025
#define IDC_SUBJECT                     1025
#define IDCANCLE                        1025
#define IDC_SE_CLASS                    1026
#define IDC_SE_NAME                     1027
#define IDC_EDIT1                       1027
#define IDC_SE_SUB                      1028
#define IDC_EDIT2                       1028
#define IDC_EDIT3                       1029
#define ID_USER_MSG                     32771
#define ID_STU_MSG                      32772
#define ID_SCORE_INPUT                  32773
#define ID_SCORE_SEARCH                 32774
#define IDC_WRITER                      32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
