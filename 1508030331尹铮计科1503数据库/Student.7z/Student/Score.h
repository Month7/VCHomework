#if !defined(AFX_SCORE_H__C7154252_0B14_4127_9E7D_2F0A184BFEAC__INCLUDED_)
#define AFX_SCORE_H__C7154252_0B14_4127_9E7D_2F0A184BFEAC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Score.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CScore dialog

class CScore : public CDialog
{
// Construction
public:
	CScore(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CScore)
	enum { IDD = IDD_DIALOG_SCORE };
	CString	m_strScore;
	CString	m_strMakeup;
	BOOL	m_bAbsent;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScore)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CScore)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCORE_H__C7154252_0B14_4127_9E7D_2F0A184BFEAC__INCLUDED_)
